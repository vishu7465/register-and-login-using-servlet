package com.vishu.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.vishu.model.registermodel;

public class registerDao {

	
	
	public int insert(registermodel rm) {
		int i = 0;
		
		try (Connection con = Dao.getConnection();) {
			PreparedStatement ps = con.prepareStatement("insert into reg values(?,?,?)");
			ps.setString(1, rm.getName());	
			ps.setString(2, rm.getEmail());	
			ps.setString(3, rm.getPassword());
			
			i = ps.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
		return i;
	}
}
