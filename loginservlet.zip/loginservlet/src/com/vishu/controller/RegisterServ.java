package com.vishu.controller;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vishu.Dao.Dao;
import com.vishu.Dao.registerDao;
import com.vishu.model.registermodel;

import javax.servlet.annotation.WebServlet;
@WebServlet("/RegisterSer")
public class RegisterServ extends HttpServlet{
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
doPost(req, resp);

		}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		PrintWriter pw= resp.getWriter();
		
		String name=req.getParameter("txtname");
		String Email=req.getParameter("txtemail");
		String password=req.getParameter("txtpass");
		registermodel rm=new registermodel();

		rm.setName(name);
		rm.setEmail(Email);
		rm.setPassword(password);
	
		registerDao rd=new registerDao();
		int i=rd.insert(rm);
		
		if(i >0) {
			System.out.println("done");
			resp.sendRedirect("Studentlogin.jsp");
		}else {
			
			resp.sendRedirect("Studentregister.jsp");
		}
		

		
		
		
		

	
	
	
	
	}
}
