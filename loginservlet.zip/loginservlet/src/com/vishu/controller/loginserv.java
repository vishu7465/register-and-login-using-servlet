package com.vishu.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

import com.vishu.Dao.Dao;
import com.vishu.Dao.registerDao;
import com.vishu.model.registermodel;
@WebServlet("/loginser")
public class loginserv extends HttpServlet {

	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
doPost(req, resp);

		}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		PrintWriter po=resp.getWriter();
		
		String email=req.getParameter("txtemail");
		String password=req.getParameter("txtpass");

		try(Connection con=Dao.getConnection();){
			
		PreparedStatement ps=con.prepareStatement("select * from reg where email=?and pass=?");  
		registermodel rm=new registermodel();		
		ps.setString(1,email); 
				ps.setString(2,password);
				
				
				ResultSet rs=ps.executeQuery();  
				
				if(rs.next()) {
					
				System.out.println("done");
					resp.sendRedirect("tuduhome.jsp");
				}
				else {
				System.out.println("Failed");
				resp.sendRedirect("studentlogin.jsp");
				}
		
		}	
		
	 catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		
		
		
		
		
	
}
			   
			    
}
}